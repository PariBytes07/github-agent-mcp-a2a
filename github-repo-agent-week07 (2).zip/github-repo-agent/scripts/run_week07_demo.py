from __future__ import annotations
import json
from pathlib import Path

from gh_agent.protocol_runtime import ProtocolRuntime

OUT = Path('examples/week07_outputs')
OUT.mkdir(parents=True, exist_ok=True)

runtime = ProtocolRuntime(github_repo='owner/repo')

review = runtime.review_flow(commit_range='HEAD~1..HEAD')
(OUT / 'protocol_review.json').write_text(json.dumps({
    'mcp_initialize': review.mcp_initialize,
    'agent_cards': review.agent_cards,
    'transcript': review.transcript,
    'artifacts': review.artifacts,
}, indent=2), encoding='utf-8')

runtime2 = ProtocolRuntime(github_repo='owner/repo')
draft = runtime2.draft_from_instruction(
    kind='issue',
    instruction='Create an issue for missing validation around GitHub repository configuration',
)
(OUT / 'protocol_draft_issue.json').write_text(json.dumps({
    'mcp_initialize': draft.mcp_initialize,
    'agent_cards': draft.agent_cards,
    'transcript': draft.transcript,
    'artifacts': draft.artifacts,
}, indent=2), encoding='utf-8')

runtime3 = ProtocolRuntime(github_repo='owner/repo')
improve = runtime3.improve_remote_item(
    kind='issue',
    number=42,
    title='Investigate login bug',
    body='Users reported a bug. Maybe fix it soon.',
)
(OUT / 'protocol_improve_issue.json').write_text(json.dumps({
    'mcp_initialize': improve.mcp_initialize,
    'agent_cards': improve.agent_cards,
    'transcript': improve.transcript,
    'artifacts': improve.artifacts,
}, indent=2), encoding='utf-8')

summary = Path('examples/week07_demo_summary.md')
summary.write_text(
    '# Week 7 Protocol Demo\n\n'
    '- `protocol_review.json`: review path using MCP git tools and A2A message passing.\n'
    '- `protocol_draft_issue.json`: explicit issue drafting path.\n'
    '- `protocol_improve_issue.json`: critique-first improvement path.\n',
    encoding='utf-8'
)
print('Wrote demo outputs to', OUT)
