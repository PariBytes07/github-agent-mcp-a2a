# Week 7 Protocol Mapping

## How the original Week 5/6 agent changed

The original repository already had the four required roles:
- Reviewer
- Planner
- Writer
- Gatekeeper

For Week 7, the same roles are preserved, but the integration boundary changed:

1. **MCP for tooling**
   - Git operations are exposed as MCP tools (`git_diff_base`, `git_diff_range`, `git_changed_files_from_diff`, `git_current_branch`)
   - Local file reads are exposed as `read_text_file`
   - GitHub fetch/create operations are exposed as `github_get_issue`, `github_get_pr`, `github_create_issue`, `github_create_pr`

2. **A2A for agent-to-agent communication**
   - Agents no longer call one another conceptually by direct function responsibility
   - Each handoff is represented as a structured A2A message envelope with sender, recipient, task id, timestamp, and payload
   - The transcript becomes auditable and can be shown in the report

## Task coverage

### Review changes
- Orchestrator asks MCP for git diff
- Reviewer sends a grounded review report to Planner over A2A
- Planner sends a plan to Writer over A2A
- If action is needed, Writer drafts and Gatekeeper reflects before any side effect

### Draft issue or PR
- Orchestrator sends explicit instruction to Writer over A2A
- Writer drafts the artifact
- Gatekeeper validates the draft
- GitHub creation remains blocked until explicit human approval

### Improve existing issue or PR
- MCP fetches the issue/PR body from GitHub (or a local override is used in the demo)
- Reviewer critiques first
- Writer proposes the structured rewrite second
- Gatekeeper records the reflection verdict

## Why this helps
- Protocol boundaries make the system easier to inspect and explain
- Tool access is standardized instead of being embedded inside arbitrary prompts
- Agent communication is logged as data instead of being hidden in direct calls
