# GitHub Repository Agent (CLI + n8n Protocol Upgrade)

This repository contains the Week 5/6 personalized GitHub repository agent and the Week 7 protocol extension.

## Core capabilities carried over from Week 5/6
- Review local git changes with evidence from real diffs
- Draft GitHub Issues and Pull Requests with a human approval gate
- Improve an existing Issue or PR by critiquing first and then proposing a structured rewrite
- Keep the four logical roles visible: Reviewer, Planner, Writer, and Gatekeeper

## Week 7 upgrade: MCP + A2A
Week 7 adds two protocol layers on top of the original design:

- **MCP for tooling**: tool access is exposed through a local MCP-style server/client boundary rather than being embedded directly inside agent logic.
- **A2A for agent-to-agent communication**: Reviewer, Planner, Writer, and Gatekeeper communicate through structured message envelopes instead of informal direct handoffs.

### What is included for Week 7
- `gh_agent/protocols/mcp.py` - local MCP-style server and client with `tools/list` and `tools/call`
- `gh_agent/protocols/a2a.py` - local A2A-style agent cards, envelopes, and transcript bus
- `gh_agent/protocol_runtime.py` - protocol-aware runtime that preserves the Week 5/6 task flow
- `n8n/docker-compose.n8n.yml` - local n8n hosting config
- `n8n/workflows/week07_mcp_a2a_github_agent.json` - importable n8n workflow showing MCP + A2A orchestration
- `.well-known/agent-card.json` - sample agent card for discovery
- `examples/week07_outputs/*.json` - demo execution artifacts
- `docs/week07_protocol_mapping.md` - concise explanation of how the protocols map to the required tasks

## Requirements
- Python 3.10+
- A git repository (run inside your repo)
- GitHub token for fetch/create operations:
  - `export GITHUB_TOKEN="..."`
  - `export GITHUB_REPO="owner/repo"`

## Install
```bash
python -m venv .venv
source .venv/bin/activate
pip install -U pip
pip install -e .
```

## Week 5/6 CLI commands

### Review
```bash
gh_agent review --base main
gh_agent review --range HEAD~3..HEAD
```

### Draft from instruction
```bash
gh_agent draft issue --instruction "Add rate limiting to login endpoint"
gh_agent draft pr --instruction "Refactor duplicated pricing logic"
```

### Draft from last review
```bash
gh_agent draft from-review
```

### Approve or reject
```bash
gh_agent approve --yes
gh_agent approve --no
```

### Improve existing
```bash
gh_agent improve issue --number 42
gh_agent improve pr --number 17
```

## Week 7 protocol-aware commands

### Review through MCP + A2A
```bash
gh_agent protocol-review --range HEAD~1..HEAD
```

### Draft through MCP + A2A
```bash
gh_agent protocol-draft --kind issue --instruction "Create an issue for missing validation in login API"
```

### Improve through MCP + A2A
```bash
gh_agent protocol-improve --kind issue --title "Investigate login bug" --body "Users reported a bug. Maybe fix it soon."
```

## Run the Week 7 demo artifacts
```bash
PYTHONPATH=. python scripts/run_week07_demo.py
```
This writes JSON artifacts under `examples/week07_outputs/`.

## Run locally with n8n
```bash
cd n8n
docker compose -f docker-compose.n8n.yml up -d
```
Then import `workflows/week07_mcp_a2a_github_agent.json` into your local n8n instance.

## Human approval policy
Even with the protocol upgrade, creation of an Issue or PR still requires explicit human approval. The Gatekeeper blocks GitHub mutation when reflection fails or approval is not granted.

## Suggested GitHub repository link for the report
Use your pushed repository URL here. If you are continuing the earlier repo, the report can point to:
`https://github.com/PariBytes07/github-ripo-agent/tree/main`
