# Week 07 Submission Checklist

Upload these files for Week 07:

1. `week07_agentic_protocols_report.docx`
2. `week07_agentic_protocols_report.pdf`
3. `github-repo-agent-week07.zip`

Repository contents included for grading:
- `gh_agent/protocols/mcp.py`
- `gh_agent/protocols/a2a.py`
- `gh_agent/protocol_runtime.py`
- `n8n/docker-compose.n8n.yml`
- `n8n/workflows/week07_mcp_a2a_github_agent.json`
- `.well-known/agent-card.json`
- `examples/week07_outputs/*.json`
- `docs/week07_protocol_mapping.md`
- `docs/week07_agentic_protocols_report.md`
