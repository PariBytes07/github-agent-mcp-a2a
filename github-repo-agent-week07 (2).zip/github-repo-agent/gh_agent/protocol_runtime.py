from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Optional

from .agents.gatekeeper import GatekeeperAgent
from .agents.planner import PlannerAgent
from .agents.reviewer import ReviewerAgent
from .agents.writer import WriterAgent
from .llm import LLM
from .protocols.a2a import A2ABus, A2AMessage, AgentCard
from .protocols.mcp import LocalMCPClient, LocalMCPServer
from .schemas import ReviewReport


@dataclass
class ProtocolRunResult:
    mcp_initialize: Dict[str, Any]
    tools_list: list[Dict[str, Any]]
    agent_cards: list[Dict[str, Any]]
    transcript: list[Dict[str, Any]]
    artifacts: Dict[str, Any]


class ProtocolRuntime:
    """Week 7 runtime: MCP for tools, A2A for inter-agent messages."""

    def __init__(self, github_token: str = "", github_repo: str = "", llm_provider: str = "mock", llm_model: str = "mock-structured") -> None:
        self.llm = LLM(provider=llm_provider, model=llm_model)
        self.reviewer = ReviewerAgent(llm=self.llm)
        self.planner = PlannerAgent(llm=self.llm)
        self.writer = WriterAgent(llm=self.llm)
        self.gatekeeper = GatekeeperAgent(llm=self.llm)
        self.bus = A2ABus()
        self.mcp_server = LocalMCPServer(github_token=github_token, github_repo=github_repo)
        self.mcp_client = LocalMCPClient(self.mcp_server)
        self.cards = [
            AgentCard(
                name="Reviewer",
                description="Analyzes diff evidence and identifies issues or improvements.",
                endpoint="local://reviewer",
                capabilities=["review_changes", "critique_issue_or_pr"],
            ),
            AgentCard(
                name="Planner",
                description="Decides the next action and plans the workflow.",
                endpoint="local://planner",
                capabilities=["decide_action", "make_plan"],
            ),
            AgentCard(
                name="Writer",
                description="Drafts issue and PR content from instructions or review artifacts.",
                endpoint="local://writer",
                capabilities=["draft_issue", "draft_pr", "rewrite_existing"],
            ),
            AgentCard(
                name="Gatekeeper",
                description="Checks policy, evidence, and human approval before side effects.",
                endpoint="local://gatekeeper",
                capabilities=["reflect_issue", "reflect_pr", "enforce_approval"],
            ),
        ]

    def review_flow(self, *, base: Optional[str] = None, commit_range: Optional[str] = None) -> ProtocolRunResult:
        if bool(base) == bool(commit_range):
            raise ValueError("Provide exactly one of base or commit_range.")

        mcp_init = self.mcp_client.initialize()
        tools = self.mcp_client.list_tools()
        diff_res = self.mcp_client.call_tool("git_diff_base", {"base": base}) if base else self.mcp_client.call_tool("git_diff_range", {"range": commit_range})
        changed = self.mcp_client.call_tool("git_changed_files_from_diff", {"diff_text": diff_res["diff_text"]})

        self.bus.send(
            A2AMessage(
                sender="Orchestrator",
                recipient="Reviewer",
                message_type="review_request",
                payload={"command": diff_res["command"], "changed_files": changed["changed_files"]},
            )
        )
        review = self.reviewer.run(diff_text=diff_res["diff_text"], changed_files=changed["changed_files"])
        self.bus.send(
            A2AMessage(
                sender="Reviewer",
                recipient="Planner",
                message_type="review_report",
                payload=review.model_dump(),
            )
        )
        plan = self.planner.run(review=review, inputs=[diff_res["command"], f"changed_files={changed['changed_files']}"])
        self.bus.send(
            A2AMessage(
                sender="Planner",
                recipient="Writer",
                message_type="plan_artifact",
                payload=plan.model_dump(),
            )
        )

        draft = None
        reflection = None
        if review.decision != "no_action":
            draft_obj = self.writer.draft_from_review(review=review, changed_files=changed["changed_files"])
            draft = draft_obj.model_dump()
            self.bus.send(
                A2AMessage(
                    sender="Writer",
                    recipient="Gatekeeper",
                    message_type="draft_artifact",
                    payload=draft,
                )
            )
            if review.decision == "create_pr":
                reflection = self.gatekeeper.reflect_pr(draft).model_dump()
            else:
                reflection = self.gatekeeper.reflect_issue(draft).model_dump()
            self.bus.send(
                A2AMessage(
                    sender="Gatekeeper",
                    recipient="Orchestrator",
                    message_type="reflection_verdict",
                    payload=reflection,
                )
            )

        return ProtocolRunResult(
            mcp_initialize=mcp_init,
            tools_list=tools,
            agent_cards=[c.to_dict() for c in self.cards],
            transcript=self.bus.conversation(),
            artifacts={
                "diff_command": diff_res["command"],
                "changed_files": changed["changed_files"],
                "review_report": review.model_dump(),
                "plan": plan.model_dump(),
                "draft": draft,
                "reflection": reflection,
            },
        )

    def draft_from_instruction(self, kind: str, instruction: str, risk: str = "medium") -> ProtocolRunResult:
        mcp_init = self.mcp_client.initialize()
        tools = self.mcp_client.list_tools()
        self.bus.send(
            A2AMessage(
                sender="Orchestrator",
                recipient="Writer",
                message_type="draft_request",
                payload={"kind": kind, "instruction": instruction, "risk": risk},
            )
        )
        if kind == "issue":
            draft_obj = self.writer.draft_issue(instruction=instruction, evidence=[], risk=risk)
            reflection = self.gatekeeper.reflect_issue(draft_obj.model_dump()).model_dump()
        else:
            draft_obj = self.writer.draft_pr(instruction=instruction, files=[], risk=risk)
            reflection = self.gatekeeper.reflect_pr(draft_obj.model_dump()).model_dump()
        self.bus.send(
            A2AMessage(
                sender="Writer",
                recipient="Gatekeeper",
                message_type="draft_artifact",
                payload=draft_obj.model_dump(),
            )
        )
        self.bus.send(
            A2AMessage(
                sender="Gatekeeper",
                recipient="Orchestrator",
                message_type="reflection_verdict",
                payload=reflection,
            )
        )
        return ProtocolRunResult(
            mcp_initialize=mcp_init,
            tools_list=tools,
            agent_cards=[c.to_dict() for c in self.cards],
            transcript=self.bus.conversation(),
            artifacts={"draft": draft_obj.model_dump(), "reflection": reflection},
        )

    def improve_remote_item(self, *, kind: str, number: int, title: str = "", body: str = "") -> ProtocolRunResult:
        mcp_init = self.mcp_client.initialize()
        tools = self.mcp_client.list_tools()
        payload: Dict[str, Any]
        if title or body:
            payload = {"title": title, "body": body, "source": "local_override"}
        else:
            tool_name = "github_get_issue" if kind == "issue" else "github_get_pr"
            fetched = self.mcp_client.call_tool(tool_name, {"number": number})
            payload = {"title": fetched.get("title", ""), "body": fetched.get("body", "") or "", "source": tool_name}

        self.bus.send(
            A2AMessage(
                sender="Orchestrator",
                recipient="Reviewer",
                message_type="improve_request",
                payload={"kind": kind, "number": number, **payload},
            )
        )

        critique = {
            "missing": [],
            "vagueness": [],
            "acceptance_criteria_quality": [],
            "evidence_quality": [],
        }
        body_text = payload["body"]
        if "acceptance" not in body_text.lower():
            critique["missing"].append("No explicit acceptance criteria section.")
        if "test" not in body_text.lower():
            critique["missing"].append("No test plan / verification section.")
        if len(body_text.strip()) < 80:
            critique["vagueness"].append("Body is short and likely misses context or scope.")

        improved = {
            "title": payload["title"] or f"Improve {kind} description",
            "body": (
                "## Context\n(Explain background and why this matters.)\n\n"
                "## Problem\n(Describe the current behavior and what is wrong.)\n\n"
                "## Evidence\n- Reference the diff, logs, screenshot, or failing path\n"
                "- Add exact reproduction steps when possible\n\n"
                "## Acceptance Criteria\n- [ ] Define expected behavior\n"
                "- [ ] Add/update tests\n"
                "- [ ] Cover edge cases and failure handling\n\n"
                "## Risk\n(low/medium/high) with one-line justification\n\n"
                "## Test Plan\n- [ ] Unit tests\n- [ ] Integration/E2E if needed\n- [ ] Manual verification\n"
            ),
        }
        self.bus.send(
            A2AMessage(
                sender="Reviewer",
                recipient="Writer",
                message_type="critique_artifact",
                payload=critique,
            )
        )
        self.bus.send(
            A2AMessage(
                sender="Writer",
                recipient="Gatekeeper",
                message_type="rewrite_artifact",
                payload=improved,
            )
        )
        reflection = {"verdict": "PASS", "reasons": ["Critique produced before rewrite; no remote mutation performed."]}
        self.bus.send(
            A2AMessage(
                sender="Gatekeeper",
                recipient="Orchestrator",
                message_type="reflection_verdict",
                payload=reflection,
            )
        )
        return ProtocolRunResult(
            mcp_initialize=mcp_init,
            tools_list=tools,
            agent_cards=[c.to_dict() for c in self.cards],
            transcript=self.bus.conversation(),
            artifacts={"critique": critique, "improved": improved, "reflection": reflection},
        )
