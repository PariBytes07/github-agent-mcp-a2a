from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List
from uuid import uuid4


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass
class AgentCard:
    name: str
    description: str
    endpoint: str
    version: str = "0.1.0"
    capabilities: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "url": self.endpoint,
            "version": self.version,
            "capabilities": self.capabilities,
        }


@dataclass
class A2AMessage:
    sender: str
    recipient: str
    message_type: str
    payload: Dict[str, Any]
    task_id: str = field(default_factory=lambda: str(uuid4()))
    timestamp: str = field(default_factory=_utc_now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_id": self.task_id,
            "sender": self.sender,
            "recipient": self.recipient,
            "message_type": self.message_type,
            "timestamp": self.timestamp,
            "payload": self.payload,
        }


class A2ABus:
    """A tiny local A2A-style bus for agent-to-agent communication.

    This is intentionally simple and file/demo friendly: agents exchange
    structured envelopes instead of calling one another directly.
    """

    def __init__(self) -> None:
        self._messages: List[A2AMessage] = []

    def send(self, msg: A2AMessage) -> None:
        self._messages.append(msg)

    def conversation(self) -> List[Dict[str, Any]]:
        return [m.to_dict() for m in self._messages]
