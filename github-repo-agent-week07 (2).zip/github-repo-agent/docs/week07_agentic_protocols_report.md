# Week 7 Report: Integrating Agentic Protocols into the Week 5/6 GitHub Agent

**GitHub repository link:** https://github.com/PariBytes07/github-ripo-agent/tree/main  
**System used:** local Python repository agent + locally hosted n8n workflow

This week I extended my Week 5/6 personalized GitHub repository agent by adding two protocol layers: Model Context Protocol (MCP) for tooling and Agent-to-Agent (A2A) messaging for communication between the Reviewer, Planner, Writer, and Gatekeeper. I did not replace the earlier system. Instead, I kept the same task goals and upgraded the way the parts of the system connect to one another.

## 1. MCP integration for tooling

In my original Week 5 agent, tool access was implemented directly inside the CLI code. The agent called Python helper functions for `git diff`, file reads, and GitHub API operations. For Week 7, I moved that boundary into a local MCP-style tool server and client. The new file `gh_agent/protocols/mcp.py` exposes tools such as `git_diff_base`, `git_diff_range`, `git_changed_files_from_diff`, `read_text_file`, `github_get_issue`, `github_get_pr`, `github_create_issue`, and `github_create_pr`.

This change matters because the agents no longer need to know how each tool works internally. They only need to request a tool through a consistent interface. In practice, that means the Reviewer can ask for a diff through MCP, the improvement flow can fetch an issue or PR through MCP, and the Gatekeeper can still block all creation until there is human approval. The protocol layer therefore keeps the system grounded in real evidence while also making tool access more modular and easier to swap or extend later.

## 2. A2A integration for agent-to-agent communication

For Week 5/6, the system already had the four required roles, but the communication between them was mostly implicit in the Python call order. In Week 7, I made those handoffs explicit with structured A2A-style messages. The new file `gh_agent/protocols/a2a.py` defines agent cards, message envelopes, and a local transcript bus. Each message records a sender, recipient, message type, timestamp, task id, and payload.

This allowed me to model the workflow more clearly:
- The Orchestrator sends a `review_request` to the Reviewer.
- The Reviewer sends a `review_report` to the Planner.
- The Planner sends a `plan_artifact` to the Writer.
- The Writer sends a `draft_artifact` or `rewrite_artifact` to the Gatekeeper.
- The Gatekeeper returns a `reflection_verdict` before any side effect is allowed.

This change improved traceability. Instead of saying the agents “worked together,” I can now show the exact transcript of their communication in `examples/week07_outputs/`. That makes the design easier to explain and better aligned with the Week 7 requirement to use agentic protocols explicitly.

## 3. Applying the protocols to the Week 5/6 tasks

I preserved all three required task types:

**Review changes.** The Week 7 runtime in `gh_agent/protocol_runtime.py` uses MCP to obtain the diff and changed files, then uses A2A messages to pass the review and planning artifacts between agents. A demo review run is saved in `examples/week07_outputs/protocol_review.json`.

**Draft and create Issue/PR.** Explicit drafting now still uses the Writer and Gatekeeper, but the request is framed as an A2A draft request and the available GitHub actions are exposed through MCP. The Gatekeeper continues to enforce human approval before creation. The explicit issue drafting demo is saved in `examples/week07_outputs/protocol_draft_issue.json`.

**Improve existing Issue/PR.** The improvement flow fetches the issue or PR through MCP or accepts a local override for demo purposes, then forces the Reviewer to critique first and the Writer to rewrite second. The saved demo in `examples/week07_outputs/protocol_improve_issue.json` shows this critique-first behavior clearly.

## 4. Local n8n workflow

I also created a local n8n component so the protocol architecture is not limited to the CLI. The file `n8n/docker-compose.n8n.yml` provides a simple local hosting setup, and `n8n/workflows/week07_mcp_a2a_github_agent.json` is an importable workflow that mirrors the same stages: request setup, A2A envelope creation, MCP tool call stub, Reviewer, Planner, Writer, Gatekeeper, and approval check. This keeps the Week 6 n8n direction while showing how Week 7 protocols fit into a visual workflow.

## 5. What I gained from protocolizing the system

The main benefit of MCP was separation of concerns. Tool access became a standardized layer rather than an implementation detail buried in agent prompts or orchestration code. The main benefit of A2A was visibility. The agent roles are no longer just conceptual labels; they now exchange explicit messages that can be logged and inspected.

The trade-off is added complexity. A small local project does not strictly need protocol layers, and the code is now more verbose than the Week 5 version. However, for an agentic software engineering system, I think this is a worthwhile trade. The design is more auditable, more modular, and easier to justify academically because the protocol boundaries are visible in both code and execution artifacts.

## Conclusion

Overall, Week 7 turned my Week 5/6 GitHub agent into a more realistic protocol-based system. MCP now handles tooling, A2A now handles communication, and the same software engineering tasks are preserved with clearer boundaries and better auditability. The repository therefore shows not just a working multi-agent workflow, but a protocol-oriented version of that workflow that is easier to inspect, extend, and defend in a report or demo.
