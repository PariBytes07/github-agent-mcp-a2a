from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Dict, List

from ..tools_fs import read_text_file
from ..tools_git import (
    git_changed_files_from_diff,
    git_current_branch,
    git_diff_base,
    git_diff_range,
)
from ..tools_github import GitHubClient


@dataclass
class MCPTool:
    name: str
    description: str
    input_schema: Dict[str, Any]
    handler: Callable[[Dict[str, Any]], Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "inputSchema": self.input_schema,
        }


class LocalMCPServer:
    """Minimal local MCP-style tool server.

    Supports the MCP concepts used in the assignment:
    - tools/list
    - tools/call
    """

    def __init__(self, github_token: str = "", github_repo: str = "") -> None:
        self.github_token = github_token
        self.github_repo = github_repo
        self._tools: Dict[str, MCPTool] = {}
        self._register_default_tools()

    def _register(self, tool: MCPTool) -> None:
        self._tools[tool.name] = tool

    def _register_default_tools(self) -> None:
        self._register(
            MCPTool(
                name="git_diff_base",
                description="Run git diff from merge-base(base, HEAD) to HEAD.",
                input_schema={"type": "object", "required": ["base"], "properties": {"base": {"type": "string"}}},
                handler=lambda args: git_diff_base(args["base"]).__dict__,
            )
        )
        self._register(
            MCPTool(
                name="git_diff_range",
                description="Run git diff for a commit range like HEAD~3..HEAD.",
                input_schema={"type": "object", "required": ["range"], "properties": {"range": {"type": "string"}}},
                handler=lambda args: git_diff_range(args["range"]).__dict__,
            )
        )
        self._register(
            MCPTool(
                name="git_changed_files_from_diff",
                description="Extract changed files from a git diff text blob.",
                input_schema={"type": "object", "required": ["diff_text"], "properties": {"diff_text": {"type": "string"}}},
                handler=lambda args: {"changed_files": git_changed_files_from_diff(args["diff_text"])},
            )
        )
        self._register(
            MCPTool(
                name="git_current_branch",
                description="Return the current git branch name.",
                input_schema={"type": "object", "properties": {}},
                handler=lambda args: {"branch": git_current_branch()},
            )
        )
        self._register(
            MCPTool(
                name="read_text_file",
                description="Read a local text file with a size cap.",
                input_schema={
                    "type": "object",
                    "required": ["path"],
                    "properties": {
                        "path": {"type": "string"},
                        "max_bytes": {"type": "integer"},
                    },
                },
                handler=lambda args: {
                    "path": args["path"],
                    "content": read_text_file(args["path"], max_bytes=int(args.get("max_bytes", 50000))),
                },
            )
        )
        self._register(
            MCPTool(
                name="github_get_issue",
                description="Fetch an issue from GitHub by number.",
                input_schema={"type": "object", "required": ["number"], "properties": {"number": {"type": "integer"}}},
                handler=self._github_get_issue,
            )
        )
        self._register(
            MCPTool(
                name="github_get_pr",
                description="Fetch a pull request from GitHub by number.",
                input_schema={"type": "object", "required": ["number"], "properties": {"number": {"type": "integer"}}},
                handler=self._github_get_pr,
            )
        )
        self._register(
            MCPTool(
                name="github_create_issue",
                description="Create a GitHub issue after human approval.",
                input_schema={
                    "type": "object",
                    "required": ["title", "body"],
                    "properties": {"title": {"type": "string"}, "body": {"type": "string"}},
                },
                handler=self._github_create_issue,
            )
        )
        self._register(
            MCPTool(
                name="github_create_pr",
                description="Create a GitHub pull request after human approval.",
                input_schema={
                    "type": "object",
                    "required": ["title", "body", "head", "base"],
                    "properties": {
                        "title": {"type": "string"},
                        "body": {"type": "string"},
                        "head": {"type": "string"},
                        "base": {"type": "string"},
                    },
                },
                handler=self._github_create_pr,
            )
        )

    def list_tools(self) -> List[Dict[str, Any]]:
        return [tool.to_dict() for tool in self._tools.values()]

    def call_tool(self, name: str, arguments: Dict[str, Any]) -> Any:
        if name not in self._tools:
            raise KeyError(f"Unknown MCP tool: {name}")
        return self._tools[name].handler(arguments)

    def _get_github(self) -> GitHubClient:
        if not self.github_repo:
            raise RuntimeError("MCP GitHub tools require github_repo to be configured.")
        return GitHubClient(token=self.github_token, repo=self.github_repo)

    def _github_get_issue(self, args: Dict[str, Any]) -> Any:
        gh = self._get_github()
        return gh.get_issue(int(args["number"]))

    def _github_get_pr(self, args: Dict[str, Any]) -> Any:
        gh = self._get_github()
        return gh.get_pr(int(args["number"]))

    def _github_create_issue(self, args: Dict[str, Any]) -> Any:
        gh = self._get_github()
        return gh.create_issue(title=args["title"], body=args["body"])

    def _github_create_pr(self, args: Dict[str, Any]) -> Any:
        gh = self._get_github()
        return gh.create_pr(title=args["title"], body=args["body"], head=args["head"], base=args["base"])


class LocalMCPClient:
    def __init__(self, server: LocalMCPServer) -> None:
        self.server = server

    def initialize(self) -> Dict[str, Any]:
        return {"protocol": "mcp", "capabilities": ["tools/list", "tools/call"]}

    def list_tools(self) -> List[Dict[str, Any]]:
        return self.server.list_tools()

    def call_tool(self, name: str, arguments: Dict[str, Any]) -> Any:
        return self.server.call_tool(name, arguments)
