# Week 7 Protocol Demo

- `protocol_review.json`: review path using MCP git tools and A2A message passing.
- `protocol_draft_issue.json`: explicit issue drafting path.
- `protocol_improve_issue.json`: critique-first improvement path.
